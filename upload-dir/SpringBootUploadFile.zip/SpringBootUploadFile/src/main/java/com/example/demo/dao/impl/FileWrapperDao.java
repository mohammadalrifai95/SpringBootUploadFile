package com.example.demo.dao.impl;

//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.sql.Statement;

public abstract class FileWrapperDao {

	// JDBC driver name and database URL
	   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   static final String DB_URL = "jdbc:mysql://localhost:3306/springbootdb";
	   								  
	   //  Database credentials
	   static final String USER = "root";
	   static final String PASS = "root";

	   
	   
}